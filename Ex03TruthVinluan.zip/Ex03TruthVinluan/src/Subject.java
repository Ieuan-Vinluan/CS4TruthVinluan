public class Subject {
    String name;
    double units;
    int gradeLevel;

    public Subject(String name, double units, int gradeLevel) {
        this.name = name;
        this.units = units;
        this.gradeLevel = gradeLevel;
    }
}